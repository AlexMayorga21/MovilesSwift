/**
 * Created by DI_GO on 17/10/2016.
 */

function ChecaSession() {
    var jsonData = {
        "action" :"CHECKSESSION"
    };
    $.ajax({
        data : jsonData,
        type : "POST",
        dataType : "json",
        contentType : "application/x-www-form-urlencoded",
        url: 'data/applicationlayer.php'
    })
        .done(function(response) {
            // Open login modal if there is no session
            console.log(response);
            if (response == 0) {
                $("#logged-in").hide();
                var as = $("#menu").children();
                as[3].style.display = "block";
                as[4].style.display = "block";
            }
            else {
                var respuesta = response;
                $("#logged-in").show();
                $("#username-navbar").text(respuesta.fname + " " + respuesta.lname);
                var as = $("#menu").children();
                as[3].style.display = "none";
                as[4].style.display = "none";
            }
        })
}

function isEmpty(value) {
    return value.trim() == "";
}

function Access() {
    $("#btnlogin").click(function () {
        var feedbackComplete = true;
        var password = $('#tfpassword').val();
        var email = $('#tfemail').val();
        var recordar = $('#loginkeeping').is(":checked");
        console.log(recordar);

        if (isEmpty(password)) {
            alert("Please, write your password.");
            feedbackComplete = false;
        }

        if (isEmpty(email)) {
            alert("Please, write an email.");
            feedbackComplete = false;
        }

        if (feedbackComplete) {
            var jsonData = {
                "action" : "LOGIN",
                "email" : email,
                "password" : password,
                "recordar" : recordar
            };
            console.log(jsonData);
            $.ajax({
                url : "data/applicationlayer.php",
                type : "POST",
                data : jsonData,
                dataType : "json",
                contentType : "application/x-www-form-urlencoded",
                success: function (jsonResponse) {
                    alert("Welcome back " + jsonResponse.fname + " " +
                        "" + jsonResponse.lname);
                    ChecaSession();
                    location.replace("index.html");
                },
                error: function (errorMessage) {
                    console.log(jsonData);
                    alert(errorMessage.responseText);
                }
            });
        }
    });
}
function LogOut(){
    $("#logout-btn").click(function() {
        $.ajax({
            url: 'data/applicationlayer.php'
        })
            .done(function() {
                alert("Has salido del sistema!");
                location.reload();
            })
    })
}

$(document).ready(function() {
    Access();
    ChecaSession();
    LogOut();
});
