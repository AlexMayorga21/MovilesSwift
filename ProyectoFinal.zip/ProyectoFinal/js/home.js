/**
 * Created by DI_GO on 16/11/2016.
 */
function ChecaSession() {
    var jsonData = {
        "action" :"CHECKSESSION"
    };
    $.ajax({
        data : jsonData,
        type : "POST",
        dataType : "json",
        contentType : "application/x-www-form-urlencoded",
        url: 'data/applicationlayer.php'
    })
        .done(function(response) {
            // Open login modal if there is no session
            console.log(response);
            if (response == 0) {
                $("#logged-in").hide();
                var as = $("#menu").children();
                as[3].style.display = "block";
                as[4].style.display = "block";
            }
            else {
                var respuesta = response;
                $("#logged-in").show();
                $("#username-navbar").text(respuesta.fname + " " + respuesta.lname);
                var as = $("#menu").children();
                as[3].style.display = "none";
                as[4].style.display = "none";
            }
        })
}

function LogOut(){
    $("#logout-btn").click(function() {
        $.ajax({
            url: 'data/applicationlayer.php'
        })
            .done(function() {
                alert("Has salido del sistema!");
                location.reload();
            })
    })
}

function GetStories() {
    var jsonData = {
        "action" : "LOAD"
    };
    $.ajax({
        url : "data/applicationlayer.php",
        dataType : "json",
        type : "POST",
        data : jsonData,
        success : function(data) {
            var newHTMLContent = "";
            var clone = $("#StoryClone").clone();
            for(i = 0; i < data.length; i++)
            {
                newHTMLContent = clone.clone();
                newHTMLContent.removeAttr("id","StoryClone");
                newHTMLContent.attr("class","StoryNoClone");
                newHTMLContent.find("#StoryNam").text(data[i].storyname);
                newHTMLContent.find("#Story").text(data[i].description);
                newHTMLContent.find("#StoryTeller").text(data[i].emailFK);
                $("#StorySection").append(newHTMLContent);
                $("#StorySection").append("<br>");
            }
            $("#StoryClone").hide();
        },
        error: function (errorMessage) {
            alert(errorMessage.responseText);
        }
    });
}

function CategoryVote () {
    $("#StorySection").on("click", ".btnhorror", function(e) {
        var target = $(e.target);
        var padre = target.parent().parent();
        var nombre = padre.find("#StoryNam").text();
        console.log(nombre);
        var jsonData = {
            "action" : "VOTE",
            "category" : "horror",
            "nombre" : nombre
        };
        $.ajax({
            url : "data/applicationlayer.php",
            dataType : "json",
            type : "POST",
            data : jsonData,
            success : function(data) {
            },
            error: function (errorMessage) {
                alert(errorMessage.responseText);
            }
        });
    });

    $("#StorySection").on("click", ".btnsad", function(e) {
        var target = $(e.target);
        var padre = target.parent().parent();
        var nombre = padre.find("#StoryNam").text();
        console.log(nombre);
        var jsonData = {
            "action" : "VOTE",
            "category" : "sad",
            "nombre" : nombre
        };
        $.ajax({
            url : "data/applicationlayer.php",
            dataType : "json",
            type : "POST",
            data : jsonData,
            success : function(data) {
            },
            error: function (errorMessage) {
                alert(errorMessage.responseText);
            }
        });
    });
    $("#StorySection").on("click", ".btncrazy", function(e) {
        var target = $(e.target);
        var padre = target.parent().parent();
        var nombre = padre.find("#StoryNam").text();
        console.log(nombre);
        var jsonData = {
            "action" : "VOTE",
            "category" : "nuts",
            "nombre" : nombre
        };
        $.ajax({
            url : "data/applicationlayer.php",
            dataType : "json",
            type : "POST",
            data : jsonData,
            success : function(data) {
            },
            error: function (errorMessage) {
                alert(errorMessage.responseText);
            }
        });
    });

    $("#StorySection").on("click", ".btnfail", function(e) {
        var target = $(e.target);
        var padre = target.parent().parent();
        var nombre = padre.find("#StoryNam").text();
        console.log(nombre);
        var jsonData = {
            "action" : "VOTE",
            "category" : "fail",
            "nombre" : nombre
        };
        $.ajax({
            url : "data/applicationlayer.php",
            dataType : "json",
            type : "POST",
            data : jsonData,
            success : function(data) {
            },
            error: function (errorMessage) {
                alert(errorMessage.responseText);
            }
        });
    });

}


function isEmpty(value) {
    return value.trim() == "";
}

function TopTen() {
    var jsonData = {
        "action" : "TOP",
        "category" : "horror"
    };
    $.ajax({
        url : "data/applicationlayer.php",
        dataType : "json",
        type : "POST",
        data : jsonData,
        success : function(data) {
            console.log(data);
            var newHTMLContent = "";
            var clone = $("#StoryClone").clone();
            for(i = 0; i < data.length; i++)
            {
                newHTMLContent = clone.clone();
                newHTMLContent.removeAttr("id","StoryClone");
                newHTMLContent.attr("class","StoryNoClone");
                newHTMLContent.find("#StoryNam").text(data[i].storyname);
                newHTMLContent.find("#Story").text(data[i].description);
                newHTMLContent.find("#StoryTeller").text(data[i].emailFK);
                $("#StorySection").append(newHTMLContent);
            }
            $("#StoryClone").hide();
        },
        error: function (errorMessage) {
            alert(errorMessage.responseText);
        }
    });
    var jsonData = {
        "action" : "TOP",
        "category" : "sad"
    };
    $.ajax({
        url : "data/applicationlayer.php",
        dataType : "json",
        type : "POST",
        data : jsonData,
        success : function(data) {
            console.log(data);
            var newHTMLContent = "";
            var clone = $("#StoryClone").clone();
            for(i = 0; i < data.length; i++)
            {
                newHTMLContent = clone.clone();
                newHTMLContent.removeAttr("id","StoryClone");
                newHTMLContent.attr("class","StoryNoClone");
                newHTMLContent.find("#StoryNam").text(data[i].storyname);
                newHTMLContent.find("#Story").text(data[i].description);
                newHTMLContent.find("#StoryTeller").text(data[i].emailFK);
                $("#StorySection").append(newHTMLContent);
            }
            $("#StoryClone").hide();
        },
        error: function (errorMessage) {
            alert(errorMessage.responseText);
        }
    });
}

function PostStory() {
    $("#btnStorySubmit").click(function() {
        var feedbackComplete = true;
        var description = $('#tfstory').val();
        var storyname = $('#tfstoryname').val();
        if(isEmpty(description)) {
            alert("Please, write a story.");
            feedbackComplete = false;
        }
        if(isEmpty(storyname)) {
            alert("Please, write a name for your story.");
            feedbackComplete = false;
        }
        var jsonData = {
            "action": "STORY",
            "session": true,
            "storyname" : storyname,
            'description': description
        };
        console.log
        if(feedbackComplete) {
            $.ajax({
                url: "data/applicationlayer.php",
                type: "POST",
                data: jsonData,
                dataType: "json",
                contentType: "application/x-www-form-urlencoded",
                success: function (jsonResponse) {
                    alert("New Story of " + jsonResponse.email);
                    location.reload();
                    $('#tfstoryname').val("");
                    $('#tfstory').val("");
                },
                error: function (jsonData) {
                    console.log(jsonData);
                    alert(jsonData.responseText);
                }
            });
        }
    });
}



$(document).ready(function() {
    ChecaSession();
    LogOut();
    GetStories();
    PostStory();
    TopTen();
    CategoryVote();
});