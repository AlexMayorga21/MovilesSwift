/**
 * Created by DI_GO on 16/11/2016.
 */
function ChecaSession() {
    var jsonData = {
        "action" :"CHECKSESSION"
    };
    $.ajax({
        data : jsonData,
        type : "POST",
        dataType : "json",
        contentType : "application/x-www-form-urlencoded",
        url: 'data/applicationlayer.php'
    })
        .done(function(response) {
            // Open login modal if there is no session
            console.log(response);
            if (response == 0) {
                $("#logged-in").hide();
                var as = $("#menu").children();
                as[3].style.display = "block";
                as[4].style.display = "block";
            }
            else {
                var respuesta = response;
                $("#logged-in").show();
                $("#username-navbar").text(respuesta.fname + " " + respuesta.lname);
                var as = $("#menu").children();
                as[3].style.display = "none";
                as[4].style.display = "none";
            }
        })
}




function LogOut(){
    $("#logout-btn").click(function() {
        $.ajax({
            url: 'data/applicationlayer.php'
        })
            .done(function() {
                alert("Has salido del sistema!");
                location.reload();
            })
    })
}

$(document).ready(function() {
    ChecaSession();
    LogOut();
});