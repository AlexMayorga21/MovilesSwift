function ChecaSession() {
    var jsonData = {
        "action" :"CHECKSESSION"
    };
    $.ajax({
        data : jsonData,
        type : "POST",
        dataType : "json",
        contentType : "application/x-www-form-urlencoded",
        url: 'data/applicationlayer.php'
    })
        .done(function(response) {
            // Open login modal if there is no session
            if (response == 0) {
                $("#logged-in").hide();
                var as = $("#menu").children();
                as[3].style.display = "block";
                as[4].style.display = "block";
            }
            else {
                var respuesta = response;
                $("#logged-in").show();
                $("#username-navbar").text(respuesta.fname + " " + respuesta.lname);
                var as = $("#menu").children();
                as[3].style.display = "none";
                as[4].style.display = "none";
            }
        })
}

function LogOut(){
    $("#logout-btn").click(function() {
        $.ajax({
            url: 'data/applicationlayer.php'
        })
            .done(function() {
                alert("Has salido del sistema!");
                location.reload();
            })
    })
}

function isEmpty(value) {
    return value.trim() == "";
}

function Registration() {
    $("#btnSignUp").click(function () {
        var feedbackComplete = true;
        var password = $('#tfpassword').val();
        var passwordConfirm = $('#tfpaswwordConfirm').val();
        var email = $('#tfemail').val();
        var fName = $('#tfFirstName').val();
        var lName = $('#tfLastName').val();
        var userName = $('#tfuname').val();

        if (isEmpty(password)) {
            alert("Please, write your password.");
            feedbackComplete = false;
        }
        if (isEmpty(password)) {
            alert("Please, write your password.");
            feedbackComplete = false;
        }
        if (isEmpty(passwordConfirm)) {
            alert("Please, write your password.");
            feedbackComplete = false;
        }
        if(password!=passwordConfirm) {
            alert("Your password does not match with the confirmation, please try again");
            feedbackComplete = false;
        }
        if (isEmpty(email)) {
            alert("Please, write an email.");
            feedbackComplete = false;
        }
        if (isEmpty(userName)) {
            alert("Please, write a user name.");
            feedbackComplete = false;
        }
        if (isEmpty(fName)) {
            alert("Please, write a comment.");
            feedbackComplete = false;
        }
        if (isEmpty(lName)) {
            alert("Please, write a comment.");
            feedbackComplete = false;
        }
        if (feedbackComplete) {
            var jsonData = {
                "action" : "REGISTER",
                "fName" : fName,
                "lName" : lName,
                "email" : email,
                "password" : password,
                "username" : userName
            };
            $.ajax({
                url : "data/applicationlayer.php",
                type : "POST",
                data : jsonData,
                dataType : "json",
                contentType : "application/x-www-form-urlencoded",
                success: function (jsonResponse) {
                    console.log("Esta entrando");
                    alert(jsonResponse.message);

                },
                error: function (errorMessage) {
                    alert(errorMessage.responseText);
                }
            });
        }
    });
}

$(document).ready(function() {
    LogOut();
    Registration();
    ChecaSession();
});