-- DB NAME: longstoryshort

CREATE TABLE Users (
	  fname VARCHAR(30) NOT NULL,
    lname VARCHAR(30) NOT NULL,
    email VARCHAR(50) NOT NULL PRIMARY KEY,
    passwrd VARCHAR(50) NOT NULL,
    biography VARCHAR(200) NOT NULL,
    username VARCHAR(30) NOT NULL
);

INSERT INTO Users(fName, lName, email, passwrd, username)
VALUES  ('admin', 'admin', 'A00813211@itesm.mx', 'admin','admin'),('admin', 'admin', 'A00813211@itesm.mx', 'admin','admin');

CREATE TABLE Stories (
  storyid int NOT NULL AUTO_INCREMENT,
  storyname VARCHAR(30) NOT NULL,
  description VARCHAR (500) NOT NULL,
  horrorcount INT (6) NOT NULL,
  sadcount INT (6) NOT NULL,
  failcount INT (6) NOT NULL,
  nutscount INT (6) NOT NULL,
  emailFK  VARCHAR (50) NOT NULL,
  date DATETIME(6) NOT NULL,
  FOREIGN KEY (emailFK) REFERENCES Users(email),
  PRIMARY  KEY (storyid)
);

CREATE TABLE Favorites (
  emailFK VARCHAR (50) NOT NULL,
  storyidFK INT NOT NULL,
  FOREIGN KEY (emailFK) REFERENCES Users(email),
  FOREIGN KEY (storyidFK) REFERENCES Stories(storyid)
);

CREATE TABLE Comments (
	  commentid int NOT NULL AUTO_INCREMENT,
    comment VARCHAR(500) NOT NULL,
    date DATETIME(6) NOT NULL,
    positive int NOT NULL,
    negative int NOT NULL,
    emailFK VARCHAR(50) NOT NULL,
    FOREIGN KEY (emailFK) REFERENCES Users(email),
    PRIMARY KEY (commentid)
);
